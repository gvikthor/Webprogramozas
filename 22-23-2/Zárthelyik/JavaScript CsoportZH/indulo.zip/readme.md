Saját Neved
NEPTUN
Web-fejlesztés 2. - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Web-fejlesztés 2. kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1. Van olyan pozíció, amire senki sem jelentkezett? Írd ki a konzolra! (1 pont)
[ ] 2. Mely pozíciókra jelentkezett legalább 3 ember? Írd ki a konzolra! (1 pont)
[ ] 3. Összesen hány önkéntes jelentkezett táborszervezőnek? Írd ki a konzolra! (2 pont)
[ ] 4. Listázd ki a pozíciók neveit egy rendezetlen listába (`ul`)! (2 pont)
[ ] 5. Minden pozíció neve mellé/mögé tegyél annyi jelölőt (célszerűen ezt: `💛`), ahányan jelentkeztek, egy-egy `span` elembe. (2 pont)
[ ] 6. Ha egy jelölőre rákattintunk, változzon meg a színe (célszerűen: `💚`). (2 pont)
[ ] +1. A 6. Feladatot delegálással oldd meg. (2 pont)