<?php
require_once 'data.php'; // Ez bemásolja ide az adatokat, de ha szeretnéd, kézzel is megteheted.

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - CsoportZH</title>
</head>
<style>
    body {
        width: 60%;
        margin: auto;
        border: 1px solid black;
        padding: 50px;
    }
    h1 {
        text-align: center;
    }
</style>
<body>
    <h1>6 / 8 pont</h1>
</body>
</html>