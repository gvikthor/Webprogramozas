Kovácz Gergely Áron
C2R1Y3
Web-fejlesztés 2. - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Web-fejlesztés 2. kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1. Minden feladathoz tartozik egy div (1 pont)
[ ] 2. Feladatok divjeiben h2 címsor (1 pont)
[ ] 3. Feladatok divjeiben kép (2 pont)
[ ] 4. a. Feladatokhoz tartozó válasz és pont táblázat (2 pont)
[ ] 4. b. Válasz mezőben input (1 pont)
[ ] 5. Az egész egy űrlap (1 pont)
[ ] 6. A points.php ellenőrzi a válaszokat (2 pont)
[ ] +1. A points.php ellenőrzi a paramétereket (2 pont)