<?php require_once 'data.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - CsoportZH</title>
</head>
<style>
    body{
        width: 60%;
        margin: auto;
        border: 1px solid black;
        padding: 50px;
    }
    h2 .task-desc {
        font-weight: lighter;
    }
    .task-img {
        min-height: 500px;
    }
    table {
        width: 70%;
        margin-left: 30%;
    }
    table, tr, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    td {
        height: 50px;
    }
    .max-pts, .got-pts {
        width: 20%;
        background-color: rgb(192, 192, 192);
        text-align: center;
    }
    .task input {
        width: 95%;
        height: 100%;
        border: none;
        text-align: center;
        font-size: 20px;
        font-weight: bold;
    }
    input[type=submit] {
        width: 100%;
        height: 50px;
        margin-top: 20px;
        background-color: rgb(192, 192, 192);
        border: none;
        font-size: 20px;
        font-weight: bold;
    }
    input[type=submit]:hover {
        background-color: rgb(128, 128, 128);
    }
</style>
<body>
    <form method="GET" action="points.php">
    <?php foreach($o_tasks as $task): ?>
        <div class="task">
            <h2>
                <span class="task-num"><?=$task->id?>.</span>
                <span class="task-desc"><?=$task->description?></span>
            </h2>
            <div class="task-img">
            <?php if($task->image): ?>
                <img src="<?=$task->image?>">
            <?php endif; ?>
            </div>
            <table>
                <tr>
                    <td class="task-answer"><input name="<?=$task->id?>"></td>
                    <td class="max-pts"><?=$task->max_points?> pont</td>
                    <td class="got-pts"></td>
                </tr>
            </table>
        </div>
    <?php endforeach; ?>
    <input type="submit" value="Küldés">
    </form>
</body>
</html>