function delegate(parent, child, when, what){
    function eventHandlerFunction(event){
        let eventTarget  = event.target
        let eventHandler = this
        let closestChild = eventTarget.closest(child)

        if(eventHandler.contains(closestChild)){
            what(event, closestChild)
        }
    }

    parent.addEventListener(when, eventHandlerFunction)
}

const people = [
    {
        name: 'Rezső',
        responsibilities: ['tűzgyújtó folyadék', 'öngyújtó', 'szalonna', 'kenyér']
    },
    {
        name: 'Péter',
        responsibilities: ['tűzifa']
    },
    {
        name: 'Gergő',
        responsibilities: ['virsli', 'hagyma', 'mustár', 'ketchup', 'kifli']
    },
    {
        name: 'Áron',
        responsibilities: []
    },
    {
        name: 'Bálint',
        responsibilities: ['kézi fűrész', 'sör', 'papírpohár', 'papírtányér', 'evőeszköz']
    },
    {
        name: 'Míra',
        responsibilities: ['sió vitatrigris', 'papírtörlő']
    },
    {
        name: 'László',
        responsibilities: []
    }
]

// 1. Feladat: Van olyan ember, akinek nincs semmi felelőssége?
console.log(
    people.some(person => person.responsibilities.length == 0)
)

// 2. Feladat: Listázd ki a konzolra azokat az embereket, akiknek legalább 3 feladata van!
console.log(
    people.filter(person => person.responsibilities.length >= 3)
)

// 3. Feladat - Írd ki dinamikusan (javascripttel) az összes ember nevét egy listába!
// 4. Feladat - Minden név mellé, a `li` tagen belülre helyezd el az adott emberhez tartozó feladatokat külön-külön `span` elemekbe.
const list = document.querySelector('#people')
people.forEach(person => {
    const li = document.createElement('li')
    li.innerText = person.name
    person.responsibilities.forEach(responsibility => {
        const span = document.createElement('span')
        span.innerText = responsibility
        li.appendChild(span)
    })
    list.appendChild(li)
})

// 5. Feladat - Ha rákattintunk egy `span` elemre, alkalmazd rá a `done` stílusosztályt!
// +1. Feladat - Az 5. Feladatot delegálással oldd meg, több eseménykezelő és ciklus nélkül.
// +2. Feladat - Ha rákattintunk egy kész elemre, legyen újra nem kész (vedd le a `done` stílusosztályt).
delegate(list, 'span', 'click', (event, span) => {
    span.classList.toggle('done')
})