Ráczkevey Péter
R216KT
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1. Van olyan ember, aki több temréket is venni szeretne? A választ a konzolra írd ki!
[ ] 2. Listázd ki a konzolra azokat az embereket, akik vettek `Blåhaj` nevű terméket!
[ ] 3. Írd ki dinamikusan (javascripttel) az összes ember nevét egy-egy `person` stílusosztályú divbe!
[ ] 4. Minden név mellé, a `div` tagen belülre helyezd el az adott emberhez tartozó termékeket külön-külön `span` elemekbe.
[ ] 5. Ha rákattintunk egy `span` elemre, jelöld meg késznek (alkalmazd rá a `done` stílusosztályt)!
[ ] +1. Az 5. Feladatot delegálással oldd meg, több eseménykezelő és ciklus nélkül.
[ ] +2. Ha rákattintunk egy kész elemre, legyen újra nem kész (vedd le a `done` stílusosztályt).