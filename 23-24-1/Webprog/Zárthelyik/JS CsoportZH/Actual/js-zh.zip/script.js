function delegate(parent, child, when, what){
    function eventHandlerFunction(event){
        let eventTarget  = event.target
        let eventHandler = this
        let closestChild = eventTarget.closest(child)

        if(eventHandler.contains(closestChild)){
            what(event, closestChild)
        }
    }

    parent.addEventListener(when, eventHandlerFunction)
}

const people = [
    {
        name: 'Rezső',
        items: ['Blåhaj', 'Kallax']
    },
    {
        name: 'Péter',
        items: []
    },
    {
        name: 'Gergő',
        items: ['Blåhaj', 'Klockis']
    },
    {
        name: 'Áron',
        items: ['Malm']
    },
    {
        name: 'Bálint',
        items: ['Börder Wåll', 'Duktig', 'Lack']
    },
    {
        name: 'Míra',
        items: ['Blåhaj']
    },
    {
        name: 'László',
        items: ['Platsa']
    }
]