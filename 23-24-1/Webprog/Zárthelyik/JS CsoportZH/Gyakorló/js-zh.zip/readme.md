Saját Neved
NEPTUN
Web-fejlesztés 2. - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Web-fejlesztés 2. kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1. Van olyan ember, akinek nincs semmi felelőssége?
[ ] 2. Listázd ki a konzolra azokat az embereket, akiknek legalább 3 feladata van!
[ ] 3. Írd ki dinamikusan (javascripttel) az összes ember nevét egy listába!
[ ] 4. Minden név mellé, a `li` tagen belülre helyezd el az adott emberhez tartozó feladatokat külön-külön `span` elemekbe.
[ ] 5. Ha rákattintunk egy `span` elemre, alkalmazd rá a `done` stílusosztályt!
[ ] +1. Az 5. Feladatot delegálással oldd meg, több eseménykezelő és ciklus nélkül.
[ ] +2. Ha rákattintunk egy kész elemre, legyen újra nem kész (vedd le a `done` stílusosztályt).