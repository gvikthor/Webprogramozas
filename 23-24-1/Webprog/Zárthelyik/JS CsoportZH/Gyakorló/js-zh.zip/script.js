function delegate(parent, child, when, what){
    function eventHandlerFunction(event){
        let eventTarget  = event.target
        let eventHandler = this
        let closestChild = eventTarget.closest(child)

        if(eventHandler.contains(closestChild)){
            what(event, closestChild)
        }
    }

    parent.addEventListener(when, eventHandlerFunction)
}

const people = [
    {
        name: 'Rezső',
        responsibilities: ['tűzgyújtó folyadék', 'öngyújtó', 'szalonna', 'kenyér']
    },
    {
        name: 'Péter',
        responsibilities: ['tűzifa']
    },
    {
        name: 'Gergő',
        responsibilities: ['virsli', 'hagyma', 'mustár', 'ketchup', 'kifli']
    },
    {
        name: 'Áron',
        responsibilities: []
    },
    {
        name: 'Bálint',
        responsibilities: ['kézi fűrész', 'sör', 'papírpohár', 'papírtányér', 'evőeszköz']
    },
    {
        name: 'Míra',
        responsibilities: ['sió vitatrigris', 'papírtörlő']
    },
    {
        name: 'László',
        responsibilities: []
    }
]