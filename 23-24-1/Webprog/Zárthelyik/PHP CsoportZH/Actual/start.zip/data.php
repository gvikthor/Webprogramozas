<?php

[
    (object)[
        'id' => 0,
        'code' => 'IP-18ePROGEG',
        'name' => 'Programozás',
        'teacher' => 'Debreceni László',
        'kredit' => 6,
        'applied' => 0,
        'limit' => 5,
        'description' => 'Problémamegoldási stratégiák, az informatikai problémamegoldás alapjai. A problémák megoldásához szükséges informatikai eszközök és módszerek. A problémamegoldás lépései. A feladat, a program és a megoldás fogalma, és ezek kapcsolata. Mi a programozás, a programkészítés folyamata. Programkészítési elvek.'
    ],
    (object)[
        'id' => 1,
        'code' => 'IP-18eMATAG',
        'name' => 'Matematikai alapok',
        'teacher' => 'Miklósi Péter',
        'kredit' => 4,
        'applied' => 0,
        'limit' => 5,
        'description' => 'Algebrai, gyökös, trigonometrikus kifejezések, egyenletek és egyenlőtlenségek megoldása, logikai alapok, logikai műveletek, azonosságok, kvantoros kifejezések használata. Teljes indukció. Lineáris algebrai alapok, vektorok, műveletek, függetlenség, bázis, mátrixok, műveletek, rang, determináns, lineáris egyenletrendszer, inverz, sajátérték feladat. Euklideszi tér, szimmetrikus mátrixok. Relációk, relációk tulajdonságai, függvények, értelmezési tartomány, grafikon, transzformációk, inverz, műveletek, tulajdonságok, sorozatok, tulajdonságaik, határérték.'
    ],
    (object)[
        'id' => 2,
        'code' => 'IP-18eKRIPTO',
        'name' => 'Kriptovaluta piramisjátékok',
        'teacher' => 'Báthory Gergő',
        'kredit' => 3,
        'applied' => 0,
        'limit' => 5,
        'description' => 'Piramisjátékok működése, esettanulmányok. Kriptovaluták és a blockchain története, működése. Biztonsági rések banki rendszerrekben. Meggyőzési módszerek egy kávé mellett. Autentikus hangzású szövegek írása. A kriptovaluták és a piramisjátékok kapcsolata. Megjelenés a tartalom előtt - a weboldal mint meggyőzési eszköz.'
    ],
    (object)[
        'id' => 3,
        'code' => 'IP-18kvMISIMOSI',
        'name' => 'Pénzmosás és offshore cégek',
        'teacher' => 'Győri Rezső',
        'kredit' => 4,
        'applied' => 0,
        'limit' => 5,
        'description' => 'Tőkeáttételes offshore cégek, pénzmosás, adóelkerülés, adócsalás, adóparadicsomok, offshore cégek, offshore bankszámlák. Büntetőjogi kiskapuk, helikopteres mentés, diplomáciai mentesség. Szuverén államok és a nemzetközi jog. A nemzetközi jogi személyek és jogképességük.'
    ],
    (object)[
        'id' => 4,
        'code' => 'IP-18eGERRY',
        'name' => 'Választókörzeti csalások (gerry-mandering)',
        'teacher' => 'Pécsettes Míra',
        'kredit' => 3,
        'applied' => 0,
        'limit' => 5,
        'description' => 'Választókörzeti csalások, gerry-mandering, választási rendszer, választási csalások, választási csalások története, választási csalások a világban, választási csalások Magyarországon. Hatékony területmeghatározó algoritmusok. Választók csoportosítása statisztikai módszerekkel. Eloszlások, becslések (maximum likelihood, Bayes becslés).'
    ],
    (object)[
        'id' => 5,
        'code' => 'IP-18kvWEBPROP',
        'name' => 'Weboldalak és információs rendszerek mint a propaganda eszközei',
        'teacher' => 'Etyke Áron',
        'kredit' => 3,
        'applied' => 0,
        'limit' => 5,
        'description' => 'A weboldalak és a propaganda kapcsolata. A közösségi média szerepe a propagandában. Választási csalások eltusolása információk rendszerekkel. Webadatbázis-elméleti logikai ugrások. Szakzsargon és szakzsargongyártás.'
    ]
];
