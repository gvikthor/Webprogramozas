Ráczkevey Péter
R216KT
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1 pont : 1. Táblázatba listázás
[ ] 2 pont : 2. Kurzusok linkelése
[ ] 2 pont : 3. Kurzus adatok listázása
[ ] 3 pont : 4. Jelentkezés ellenőrzése
[ ] 2 pont : 5. Jelentkezés
[ ] 2 pont : +1. Lejelentkezés