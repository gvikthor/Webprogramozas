<?php

[
    (object)[
        'name' => 'Bratislava',
        'population' => 425000,
        'country' => 'Szlovákia'
    ],
    (object)[
        'name' => 'Győr',
        'population' => 130000,
        'country' => 'Hungary'
    ],
    (object)[
        'name' => 'Wien',
        'population' => 1900000,
        'country' => 'Austria'
    ],
    (object)[
        'name' => 'Warszawa',
        'population' => 1800000,
        'country' => 'Poland'
    ],
    (object)[
        'name' => 'Kraków',
        'population' => 760000,
        'country' => 'Poland'
    ]
]