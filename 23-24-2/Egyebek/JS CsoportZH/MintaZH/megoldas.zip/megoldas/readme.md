Ráczkevey Péter
R216KT
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[x] 01. Feladat (2 pont): 'Dűne' kiválogatás
[x] 02. Feladat (2 pont): Perc:másodperc
[x] 03. Feladat (2 pont): Táblázat generálás
[x] 04. Feladat (2 pont): Szűrés
[x] 05. Feladat (2 pont): Hossznövelés
[x] +1. Feladat (2 pont): Delegálás