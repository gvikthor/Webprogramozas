const movieInput = document.querySelector('#movie-input')
const musicTable = document.querySelector('#music-table tbody')

/**
 * Ez a függvény átalakít számként tárolt másodperceket perc:másodperc formátumú stringgé.
 * Például:  90 --> '01:30'
 */
function secondsToTimestamp(seconds){
    let min = Math.floor(seconds / 60)
    let sec = seconds % 60
    if(min < 10) min = `0${min}`
    if(sec < 10) sec = `0${sec}`
    return `${min}:${sec}`
}

/**
 * Az órai delegálás függvény.
 * Példa használat: delegate(szuloElem, '.gyerekCssSelector', 'esemeny', (event, elem) => {
 *     // példa függvény
 * })
 */
function delegate(parent, child, when, what){
    function eventHandlerFunction(event){
        let eventTarget  = event.target
        let eventHandler = this
        let closestChild = eventTarget.closest(child)

        if(eventHandler.contains(closestChild)){
            what(event, closestChild)
        }
    }

    parent.addEventListener(when, eventHandlerFunction)
}

const songs = [
    {movie: 'Dune', title: 'House Atreides', length: 226},
    {movie: 'Inception', title: 'Mombassa', length: 295},
    {movie: 'Pirates of the Caribbean', title: 'Jack Sparrow', length: 251},
    {movie: 'Inception', title: 'Time', length: 277},
    {movie: 'The Lion King', title: 'He Lives In You', length: 239},
    {movie: 'Dunkirk', title: 'Supermarine', length: 146},
    {movie: 'Dune', title: 'Paul\'s Dream', length: 328}
]

console.log(
    songs.some(song => song.movie == 'Dune')
)

console.log(
    songs.map(song => secondsToTimestamp(song.length))
)

function updateTable(){
    const movieSearchString = movieInput.value
    musicTable.innerHTML = ''
    songs
        .filter(song => song.movie.includes(movieSearchString))
        .forEach((song, index) => {
            musicTable.innerHTML += `<tr data-index="${index}">
                    <td>${song.movie}</td>
                    <td>${song.title}</td>
                    <td>${secondsToTimestamp(song.length)}</td>
                </tr>`
        })
}

updateTable()
movieInput.addEventListener('input', updateTable)
delegate(musicTable, 'tr', 'click', (event, elem) => {
    songs[elem.dataset.index].length += 10
    updateTable()
})