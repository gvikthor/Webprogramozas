Saját Nevem
NEPTUN
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[] 01. Feladat (2 pont): 'Dűne' kiválogatás
[] 02. Feladat (2 pont): Perc:másodperc
[] 03. Feladat (2 pont): Táblázat generálás
[] 04. Feladat (2 pont): Szűrés
[] 05. Feladat (2 pont): Hossznövelés
[] +1. Feladat (2 pont): Delegálás