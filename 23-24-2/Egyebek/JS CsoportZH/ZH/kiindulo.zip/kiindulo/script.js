const searchInput = document.querySelector('#search-input')
const searchButton = document.querySelector('#search-button')
const sectionUL = document.querySelector('#section-list')

/**
 * Ez a függvény átalakít számként tárolt perceket óra h perc formátumú stringgé.
 * Például:  90 --> '01h30'
 */
function minutesToTimelength(minutes){
    let h = Math.floor(minutes / 60)
    let m = minutes % 60
    if(h < 10) h = `0${h}`
    if(m < 10) m = `0${m}`
    return `${h}:${m}`
}

/**
 * Az órai delegálás függvény.
 * Példa használat: delegate(szuloElem, '.gyerekCssSelector', 'esemeny', (event, elem) => {
 *     // példa függvény
 * })
 */
function delegate(parent, child, when, what){
    function eventHandlerFunction(event){
        let eventTarget  = event.target
        let eventHandler = this
        let closestChild = eventTarget.closest(child)

        if(eventHandler.contains(closestChild)){
            what(event, closestChild)
        }
    }

    parent.addEventListener(when, eventHandlerFunction)
}

const sections = [
    {name: 'Megérkezés, lepakolás', length: 30, resources: ['catering']},
    {name: 'Csapatbeosztás játékkal', length: 15, resources: ['irodaszer']},
    {name: 'Tojásejtős játék', length: 60, resources: ['tojás', 'irodaszerek', 'kulcs a tetőhöz', 'asztalok']},
    {name: '1. Szünet', length: 10, resources: []},
    {name: 'Új álomiroda', length: 90, resources: ['irodaszerek', 'újságok', 'flipchart papír', 'asztalok']},
    {name: '2. Szünet', length: 45, resources: ['catering', 'sztalok', 'székek']},
    {name: 'Kamu projekt üzleti prezentálása', length: 90, resources: ['irodaszerek', 'flipchart papír', 'laptopok', 'powerpoint', 'kivetítő', 'asztalok', 'elosztók']},
    {name: '3. Szünet', length: 10, resources: ['catering']},
    {name: 'Story játék', length: 30, resources: ['székek']},
    {name: 'Zárókör', length: 30, resources: ['székek']}
]

