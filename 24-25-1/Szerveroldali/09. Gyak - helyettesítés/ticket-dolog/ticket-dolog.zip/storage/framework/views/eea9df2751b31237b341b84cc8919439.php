<?php $__env->startSection('title', 'Feladatok'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="ps-3">Feladatok</h1>
    <hr />
    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th style="width: 10%">Priorítás</th>
                    <th style="width: 15%">Beküldő</th>
                    <th style="width: 15%">Utolsó hozzászóló</th>
                    <th style="width: 40%">Tárgy</th>
                    <th style="width: 10%">Státusz</th>
                    <th style="width: 10%"></th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php if($ticket->priority == 2): ?> table-warning <?php elseif($ticket->priority == 3): ?> table-danger <?php endif; ?>">
                        <td>
                            <?php switch($ticket->priority):
                                case (0): ?>
                                    <span class="badge rounded-pill bg-info fs-6">Alacsony</span>
                                    <?php break; ?>
                                <?php case (1): ?>
                                    <span class="badge rounded-pill bg-success fs-6">Normál</span>
                                    <?php break; ?>
                                <?php case (2): ?>
                                    <span class="badge rounded-pill bg-warning text-black fs-6">Magas</span>
                                    <?php break; ?>
                                <?php case (3): ?>
                                    <span class="badge rounded-pill bg-danger fs-6">Azonnal</span>
                                    <?php break; ?>
                            <?php endswitch; ?>
                        </td>
                        <td>
                            <div><?php echo e($ticket->owner->first()->name); ?></div>
                            <div class="text-secondary"><?php echo e($ticket->created_at); ?></div>
                        </td>
                        <td>
                            <div><?php echo e($ticket->comments()->orderByDesc('created_at')->first()->user->name); ?></div>
                            <div class="text-secondary"><?php echo e($ticket->comments()->orderByDesc('created_at')->first()->created_at); ?></div>
                        </td>
                        <td>
                            <div>
                                <a href="<?php echo e(route('tickets.show', ['ticket' => $ticket->id])); ?>"><?php echo e($ticket->title); ?></a>
                            </div>
                        </td>
                        <td>
                            <span class="badge rounded-pill bg-info text-dark fs-6">
                                <?php if($ticket->done): ?>
                                    Lezárva
                                <?php elseif($ticket->comments()->count() == 1): ?>
                                    Új
                                <?php else: ?>
                                    Folyamatban
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-outline-secondary">
                                <i class="fa-solid fa-angles-right fa-fw"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($tickets->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ticket.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anony\Desktop\szerveroldali\laravel-rest-api\resources\views/ticket/tickets.blade.php ENDPATH**/ ?>