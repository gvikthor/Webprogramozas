Teljes Neved
NEPTUNKÓD
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1. Feladat: 300 mérföldnél hosszabb vonal  
[ ] 2. Feladat: 5 óránál hosszabb vonalak városai  
[ ] 3. Feladat: Lista generálás  
[ ] 4. Feladat: Kijelölés  
[ ] 5. Feladat: Árváltoztatás  
[ ] +. Feladat: Egyedi városok  
[ ] +. Feladat: Delegálás  