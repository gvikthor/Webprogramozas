Teljes Neved
NEPTUNKÓD
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] 1. Feladat: Atlanta - Charlotte
[ ] 2. Feladat: 200-nál hosszabb átlag
[ ] 3. Feladat: Táblázat generálás
[ ] 4. Feladat: Kijelölés
[ ] 5. Feladat: Átlag jegyár
[ ] +. Feladat: Delegálás