<?php
$csatornak = [
    (object)[
        "nev" => "Mókuscsoport",
        "influencer" => "TheFirstMan",
        "kep" => "https=>//kamrashop.hu/wp-content/uploads/2022/11/trmk-kokusz.jpg",
        "feliratkozok" => 213000
    ],
    (object)[
        "nev" => "Thisisfine",
        "influencer" => "Jockie",
        "kep" => "https=>//rozsmanncukraszda.hu/image/cache/Egy%C3%A9b/csokitabla-1000x1000.jpg",
        "feliratkozok" => 196000
    ],
    (object)[
        "nev" => "Országbérlet",
        "influencer" => "Gyermekeim Anyja",
        "kep" => "https=>//miro.medium.com/v2/resize=>fit=>687/1*urkG1quJnJIApIMyTQIe1A.jpeg",
        "feliratkozok" => 31000
    ],
    (object)[
        "nev" => "Videós Ember",
        "influencer" => "Thomas a Gőzmozdony",
        "kep"=> "https=>//simongyumolcs.hu/wp-content/uploads/2019/12/simon-gyumolcs-edes-alma.jpg",
        "feliratkozok" => 787000
    ],
    (object)[
        "nev" => "Ellenáló",
        "influencer" => "Ágnes",
        "kep" => "https=>//upload.wikimedia.org/wikipedia/commons/e/e2/Jupiter.jpg",
        "feliratkozok" => 523000
    ]
];