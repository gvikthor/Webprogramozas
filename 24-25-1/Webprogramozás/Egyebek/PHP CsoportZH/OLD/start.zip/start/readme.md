Ráczkevey Péter
R216KT
Webprogramozás - számonkérés

Ezt a megoldást a fent írt hallgató küldte be és készítette a Webprogramozás kurzus számonkéréséhez.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy használtam harmadik féltől 
származó megoldásokat. Nem továbbítottam megoldást hallgatótársaimnak, és nem is tettem közzé. 
Nem használtam mesterséges intelligencia által generált kódot, kódrészletet.
Az ELTE HKR 377/A. § értelmében, ha nem megengedett segédeszközt veszek igénybe,
vagy más hallgatónak nem megengedett segítséget nyújtok, a tantárgyat nem teljesíthetem.

[ ] - 1 pont : Csatorna név, feliratkozók, influencer
[ ] - 1 pont : Kép
[ ] - 1 pont : JSON-ből olvasás

[ ] - 1 pont : Csatorna név kötelező
[ ] - 1 pont : Csatorna név min 5 karakter
[ ] - 1 pont : Üres influencer = Csatorna név
[ ] - 1 pont : URL helyesség

[ ] - 1 pont : Főoldalra visszairányít

[ ] - 2 pont : JSON-be mentés

[ ] - +1 pont: Hibák kiírása
[ ] - +1 pont: Állapottartó